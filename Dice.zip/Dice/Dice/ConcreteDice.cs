﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dice
{
    public class ConcreteDice
    {
        private static Random rnd = new Random(Guid.NewGuid().GetHashCode());
        int _roll4 = rnd.Next(1, 5);
        int _roll6 = rnd.Next(1, 7);
        int _roll8 = rnd.Next(1, 9);
        int _roll12 = rnd.Next(1, 13);
        int _roll20 = rnd.Next(1, 21);

        public int roll4
        {

            get { return _roll4; }

        }//roll
        public int roll6
        {

            get { return _roll6; }

        }//roll
        public int roll8
        {

            get { return _roll8; }

        }//roll
        public int roll12
        {

            get { return _roll12; }

        }//roll
        public int roll20
        {

            get { return _roll20; }

        }//roll
    }
}
